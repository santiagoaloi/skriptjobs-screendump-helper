/**
 * Shared macOS Chrome Mockup Renderer (Dark & Light Themes, @skriptjobs/ui compatible)
 *
 * Measured pixel-for-pixel from Santiago's reference screenshots:
 * - Top margin: 36px, Bottom margin: 62px, Left margin: 60px, Right margin: 86px (or 60px symmetric)
 * - Window corner radius: 12px
 * - Drop shadow: 0px X-offset, +20px Y-offset, sigma=16px (34px blur), 0.62 opacity
 * - Tab bar: 39px height, traffic lights (#ff5f57, #febc2e, #28c840),
 *   active tab with Skriptjobs three-triangles favicon + title + close 'x', and '+' button (NO Ask Gemini)
 * - URL bar row: 46px height, full-width pill omnibox (34px tall, rx=17)
 *   with circular Skriptjobs three-triangles logo badge at the start of the URL bar + full URL
 *   (NO back/forward/refresh, NO right toolbar icons)
 * - Bottom header divider: 1px solid
 */

export const CHROME_MOCKUP_THEMES = {
  dark: {
    borderOuter: '#585a5f',
    borderInner: '#393344',
    viewportFallbackBg: '#3f384d',
    header: {
      tabBarHeight: 39,
      toolbarHeight: 46,
      dividerHeight: 1,
      totalHeight: 86,
      tabBarBg: '#231c2f',
      toolbarBg: '#3f384d',
      omniboxBg: '#292335',
      dividerColor: '#48444e',
      tabText: '#e6e0ee',
      tabClose: '#b8b0c4',
      newTabPlus: '#b8adc5',
      urlScheme: '#9e95ad',
      urlHost: '#f3eef8',
      urlPath: '#b8b0c8',
      omniboxBadgeBg: '#3f384d',
      omniboxLogoFill: '#f3eef8',
      faviconTileFill: '#141318',
      faviconTileStroke: '#524963',
      faviconLogoFill: '#ffffff',
    },
  },
  light: {
    borderOuter: '#f1e8fa',
    borderInner: '#d8cde2',
    viewportFallbackBg: '#fef7ff',
    header: {
      tabBarHeight: 39,
      toolbarHeight: 46,
      dividerHeight: 1,
      totalHeight: 86,
      tabBarBg: '#eadef7',
      toolbarBg: '#fef7ff',
      omniboxBg: '#ede7f2',
      dividerColor: '#e7e0eb',
      tabText: '#1d1b20',
      tabClose: '#49454f',
      newTabPlus: '#49454f',
      urlScheme: '#675e70',
      urlHost: '#1d1b20',
      urlPath: '#49454f',
      omniboxBadgeBg: '#fef7ff',
      omniboxLogoFill: '#1d1b20',
      faviconTileFill: '#141318',
      faviconTileStroke: '#d0cad5',
      faviconLogoFill: '#ffffff',
    },
  },
};

export const CHROME_MOCKUP_THEME = {
  referenceCanvas: { width: 1711, height: 1076 },
  referenceWindow: { width: 1565, height: 978 },
  margins: {
    reference: { top: 36, bottom: 62, left: 60, right: 86 },
    symmetric: { top: 36, bottom: 62, left: 60, right: 60 },
  },
  windowRadius: 12,
  borderOuter: CHROME_MOCKUP_THEMES.dark.borderOuter,
  borderInner: CHROME_MOCKUP_THEMES.dark.borderInner,
  shadow: {
    offsetX: 0,
    offsetY: 20,
    sigma: 16,
    blurCss: 34,
    alpha: 0.62,
  },
  header: CHROME_MOCKUP_THEMES.dark.header,
  trafficLights: [
    { cx: 20, cy: 20.5, r: 6, fill: '#ff5f57', stroke: '#e0443e' },
    { cx: 43, cy: 20.5, r: 6, fill: '#febc2e', stroke: '#dfa023' },
    { cx: 66, cy: 20.5, r: 6, fill: '#28c840', stroke: '#1aab29' },
  ],
};

/**
 * Official Skriptjobs three-triangles mark polygons (from bimi-logo-dark.svg / logo-three-triangles.svg, viewBox 0 0 32 32).
 */
export function buildSkriptjobsTrianglesSvgGroup({
  x = 0,
  y = 0,
  size = 16,
  fill = '#ffffff',
  withDarkTile = false,
  tileFill = '#141318',
  tileStroke = '#4d455e',
}) {
  const tileMarkup = withDarkTile
    ? `<rect x="${x}" y="${y}" width="${size}" height="${size}" rx="${(size * 0.22).toFixed(2)}" fill="${tileFill}" stroke="${tileStroke}" stroke-width="0.6" />`
    : '';
  const innerSize = withDarkTile ? size * 0.76 : size;
  const innerOffset = withDarkTile ? (size - innerSize) / 2 : 0;
  const innerScale = innerSize / 32;

  return `${tileMarkup}
  <g transform="translate(${(x + innerOffset).toFixed(2)}, ${(y + innerOffset).toFixed(2)}) scale(${innerScale.toFixed(4)})" fill="${fill}" shape-rendering="geometricPrecision">
    <polygon points="16,3.2 22.6,14.5 9.4,14.5" />
    <polygon points="8.2,17.5 14.8,28.8 1.6,28.8" />
    <polygon points="23.8,17.5 30.4,28.8 17.2,28.8" />
  </g>`;
}

/**
 * Parse a URL string into { scheme, host, path } for styled rendering in the omnibox.
 */
export function splitUrlParts(rawUrl) {
  const str = String(rawUrl || 'https://docs.skriptjobs.localhost:3050').trim();
  const match = str.match(/^([a-zA-Z][a-zA-Z0-9+.-]*:\/\/)?([^/?#]+)(.*)$/);
  if (!match) {
    return { scheme: '', host: str, path: '' };
  }
  return {
    scheme: match[1] || '',
    host: match[2] || '',
    path: match[3] || '',
  };
}

/**
 * Escape XML special characters for SVG rendering.
 */
export function escapeXml(unsafe) {
  return String(unsafe || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

/**
 * Build the crisp vector SVG for the simplified macOS Chrome header (width x 86px).
 */
export function buildChromeHeaderSvg({
  windowWidth = 1565,
  title = 'Installation - Skriptjobs',
  url = 'https://docs.skriptjobs.localhost:3050/getting-started/installation',
  faviconDataUrl = null,
  omniboxFaviconDataUrl = null,
  mockupTheme = 'dark',
}) {
  const T = CHROME_MOCKUP_THEME;
  const palette =
    mockupTheme === 'light' ? CHROME_MOCKUP_THEMES.light : CHROME_MOCKUP_THEMES.dark;
  const Hdr = palette.header;
  const H = Hdr.totalHeight; // 86
  const tabBarH = Hdr.tabBarHeight; // 39
  const toolbarH = Hdr.toolbarHeight; // 46

  // Active tab geometry
  const tabX = 93;
  const tabY = 6;
  const tabW = 267;
  const tabH = tabBarH - tabY; // 33
  const tabR = 10;
  const scoopR = 8;

  const displayTitle =
    title.length > 28 ? title.slice(0, 27).trimEnd() + '…' : title;

  const plusCx = tabX + tabW + 20; // 380
  const plusCy = tabY + tabH / 2; // 22.5

  // Omnibox geometry
  const omniX = 14;
  const omniY = tabBarH + 6; // 45
  const omniW = windowWidth - 28;
  const omniH = 34;
  const omniR = 17;

  const { scheme, host, path } = splitUrlParts(url);

  // Active Tab Favicon (uses custom faviconDataUrl if provided, otherwise Skriptjobs three-triangles)
  const tabFaviconMarkup = faviconDataUrl
    ? `<g clip-path="url(#tabFaviconClip)"><image href="${escapeXml(faviconDataUrl)}" x="${tabX + 14}" y="${tabY + 8.5}" width="16" height="16" preserveAspectRatio="xMidYMid slice" /></g>`
    : buildSkriptjobsTrianglesSvgGroup({
        x: tabX + 14,
        y: tabY + 8.5,
        size: 16,
        fill: Hdr.faviconLogoFill,
        withDarkTile: true,
        tileFill: Hdr.faviconTileFill,
        tileStroke: Hdr.faviconTileStroke,
      });

  // Omnibox Start Badge (uses custom faviconDataUrl if provided, filling the r=12 circle cleanly)
  const badgeCx = omniX + 17;
  const badgeCy = omniY + 17;
  const badgeR = 12;
  const badgeLogoSize = 16.5;
  const effectiveOmniFavicon = omniboxFaviconDataUrl || faviconDataUrl;
  const omniboxBadgeLogoMarkup = effectiveOmniFavicon
    ? `<g clip-path="url(#omniBadgeClip)"><image href="${escapeXml(effectiveOmniFavicon)}" x="${badgeCx - badgeR}" y="${badgeCy - badgeR}" width="${badgeR * 2}" height="${badgeR * 2}" preserveAspectRatio="xMidYMid slice" /></g>`
    : buildSkriptjobsTrianglesSvgGroup({
        x: badgeCx - badgeLogoSize / 2,
        y: badgeCy - badgeLogoSize / 2 - 0.3,
        size: badgeLogoSize,
        fill: Hdr.omniboxLogoFill,
        withDarkTile: false,
      });

  return `<svg xmlns="http://www.w3.org/2000/svg" width="${windowWidth}" height="${H}" viewBox="0 0 ${windowWidth} ${H}">
  <defs>
    <clipPath id="tabTitleClip">
      <rect x="${tabX + 36}" y="${tabY}" width="${tabW - 64}" height="${tabH}" />
    </clipPath>
    <clipPath id="tabFaviconClip">
      <rect x="${tabX + 14}" y="${tabY + 8.5}" width="16" height="16" rx="3.5" ry="3.5" />
    </clipPath>
    <clipPath id="omniBadgeClip">
      <circle cx="${badgeCx}" cy="${badgeCy}" r="${badgeR}" />
    </clipPath>
    <clipPath id="omniTextClip">
      <rect x="${omniX + 38}" y="${omniY}" width="${omniW - 54}" height="${omniH}" />
    </clipPath>
  </defs>

  <!-- Row 1: Tab Bar Background -->
  <rect x="0" y="0" width="${windowWidth}" height="${tabBarH}" fill="${Hdr.tabBarBg}" />

  <!-- Row 2: Toolbar Background -->
  <rect x="0" y="${tabBarH}" width="${windowWidth}" height="${toolbarH}" fill="${Hdr.toolbarBg}" />

  <!-- macOS Traffic Lights -->
  ${T.trafficLights
    .map(
      (tl) =>
        `<circle cx="${tl.cx}" cy="${tl.cy}" r="${tl.r}" fill="${tl.fill}" stroke="${tl.stroke}" stroke-width="0.5" />`
    )
    .join('\n  ')}

  <!-- Active Tab with Chrome bottom-left and bottom-right inverted fillets -->
  <path d="
    M ${tabX - scoopR} ${tabBarH}
    A ${scoopR} ${scoopR} 0 0 0 ${tabX} ${tabBarH - scoopR}
    L ${tabX} ${tabY + tabR}
    A ${tabR} ${tabR} 0 0 1 ${tabX + tabR} ${tabY}
    L ${tabX + tabW - tabR} ${tabY}
    A ${tabR} ${tabR} 0 0 1 ${tabX + tabW} ${tabY + tabR}
    L ${tabX + tabW} ${tabBarH - scoopR}
    A ${scoopR} ${scoopR} 0 0 0 ${tabX + tabW + scoopR} ${tabBarH}
    Z
  " fill="${Hdr.toolbarBg}" />

  <!-- Active Tab Favicon (Skriptjobs Three-Triangles Favicon) -->
  ${tabFaviconMarkup}

  <!-- Active Tab Title -->
  <g clip-path="url(#tabTitleClip)">
    <text x="${tabX + 38}" y="${tabY + 21}" fill="${Hdr.tabText}" font-family="'Geist', -apple-system, BlinkMacSystemFont, 'SF Pro Text', 'Inter', 'Segoe UI', sans-serif" font-size="12.5" font-weight="500">${escapeXml(displayTitle)}</text>
  </g>

  <!-- Active Tab Close 'x' -->
  <g transform="translate(${tabX + tabW - 22}, ${tabY + 16.5})" stroke="${Hdr.tabClose}" stroke-width="1.5" stroke-linecap="round">
    <line x1="-3.5" y1="-3.5" x2="3.5" y2="3.5" />
    <line x1="3.5" y1="-3.5" x2="-3.5" y2="3.5" />
  </g>

  <!-- New Tab '+' Button -->
  <g transform="translate(${plusCx}, ${plusCy})" stroke="${Hdr.newTabPlus}" stroke-width="1.7" stroke-linecap="round">
    <line x1="-5" y1="0" x2="5" y2="0" />
    <line x1="0" y1="-5" x2="0" y2="5" />
  </g>

  <!-- Row 2: Full-width Pill URL Omnibox -->
  <rect x="${omniX}" y="${omniY}" width="${omniW}" height="${omniH}" rx="${omniR}" ry="${omniR}" fill="${Hdr.omniboxBg}" />

  <!-- Omnibox Left Badge Circle + Official Skriptjobs Three-Triangles Mark -->
  <circle cx="${badgeCx}" cy="${badgeCy}" r="12" fill="${Hdr.omniboxBadgeBg}" />
  ${omniboxBadgeLogoMarkup}

  <!-- Omnibox URL Text (scheme + host + path) -->
  <g clip-path="url(#omniTextClip)">
    <text x="${omniX + 38}" y="${omniY + 22}" font-family="'Geist', -apple-system, BlinkMacSystemFont, 'SF Pro Text', 'Inter', 'Segoe UI', sans-serif" font-size="13.5" font-weight="400" xml:space="preserve"><tspan fill="${Hdr.urlScheme}">${escapeXml(scheme)}</tspan><tspan fill="${Hdr.urlHost}" font-weight="500">${escapeXml(host)}</tspan><tspan fill="${Hdr.urlPath}">${escapeXml(path)}</tspan></text>
  </g>

  <!-- Bottom 1px Divider Line -->
  <rect x="0" y="${H - 1}" width="${windowWidth}" height="1" fill="${Hdr.dividerColor}" />
</svg>`;
}

/**
 * Browser Canvas 2D renderer (used by the Chrome Extension popup, content script, & Vue component).
 * Preloads the SVG header image before modifying the target canvas so redraws never flash.
 */

const faviconNormCache = new Map();

async function normalizeFaviconForHeader(rawFaviconUrl) {
  if (!rawFaviconUrl) return { tabFaviconDataUrl: null, omniboxFaviconDataUrl: null };
  if (faviconNormCache.has(rawFaviconUrl)) {
    return faviconNormCache.get(rawFaviconUrl);
  }
  try {
    const img = await new Promise((resolve, reject) => {
      const el = new Image();
      el.crossOrigin = "anonymous";
      el.onload = () => resolve(el);
      el.onerror = reject;
      el.src = rawFaviconUrl;
    });

    const S = 64;
    const probe = document.createElement("canvas");
    probe.width = S;
    probe.height = S;
    const pctx = probe.getContext("2d");
    pctx.drawImage(img, 0, 0, S, S);
    const { data } = pctx.getImageData(0, 0, S, S);

    const idx = (x, y) => (y * S + x) * 4;
    let minX = S, minY = S, maxX = -1, maxY = -1;
    for (let y = 0; y < S; y++) {
      for (let x = 0; x < S; x++) {
        if (data[idx(x, y) + 3] > 20) {
          if (x < minX) minX = x;
          if (x > maxX) maxX = x;
          if (y < minY) minY = y;
          if (y > maxY) maxY = y;
        }
      }
    }

    if (maxX < minX || maxY < minY) {
      minX = 0; minY = 0; maxX = S - 1; maxY = S - 1;
    }

    const cropW = Math.max(1, maxX - minX + 1);
    const cropH = Math.max(1, maxY - minY + 1);
    const midX = Math.min(S - 1, Math.max(0, Math.round((minX + maxX) / 2)));
    const midY = Math.min(S - 1, Math.max(0, Math.round((minY + maxY) / 2)));
    const insetX = Math.min(3, Math.floor(cropW / 6));
    const insetY = Math.min(3, Math.floor(cropH / 6));

    const edgeSamples = [
      idx(midX, Math.min(S - 1, minY + insetY)),
      idx(midX, Math.max(0, maxY - insetY)),
      idx(Math.min(S - 1, minX + insetX), midY),
      idx(Math.max(0, maxX - insetX), midY),
    ];

    const opaqueEdges = edgeSamples.filter((i) => data[i + 3] >= 180);
    const isFilledSquare = opaqueEdges.length >= 3;

    // 1. Tab Favicon (64x64)
    const tabCanvas = document.createElement("canvas");
    tabCanvas.width = 64;
    tabCanvas.height = 64;
    const tctx = tabCanvas.getContext("2d");
    if (isFilledSquare) {
      const topI = edgeSamples[0];
      const botI = edgeSamples[1];
      const grad = tctx.createLinearGradient(0, 0, 0, 64);
      grad.addColorStop(0, `rgb(${data[topI]}, ${data[topI + 1]}, ${data[topI + 2]})`);
      grad.addColorStop(1, `rgb(${data[botI]}, ${data[botI + 1]}, ${data[botI + 2]})`);
      tctx.fillStyle = grad;
      tctx.fillRect(0, 0, 64, 64);
    }
    tctx.drawImage(probe, minX, minY, cropW, cropH, 0, 0, 64, 64);

    // 2. Omnibox Circular Badge Favicon (96x96 -> clipped to r=12 circle)
    const omniCanvas = document.createElement("canvas");
    omniCanvas.width = 96;
    omniCanvas.height = 96;
    const octx = omniCanvas.getContext("2d");

    if (isFilledSquare) {
      const topI = edgeSamples[0];
      const botI = edgeSamples[1];
      const grad = octx.createLinearGradient(0, 0, 0, 96);
      grad.addColorStop(0, `rgb(${data[topI]}, ${data[topI + 1]}, ${data[topI + 2]})`);
      grad.addColorStop(1, `rgb(${data[botI]}, ${data[botI + 1]}, ${data[botI + 2]})`);
      octx.fillStyle = grad;
      octx.fillRect(0, 0, 96, 96);
      // Draw cropped square icon slightly inset (76x76 centered in 96x96) over its own background so circle is 100% filled and inner mark is never clipped
      const inner = 76;
      const pad = (96 - inner) / 2;
      octx.drawImage(probe, minX, minY, cropW, cropH, pad, pad, inner, inner);
    } else {
      const inner = 66;
      const pad = (96 - inner) / 2;
      octx.drawImage(probe, minX, minY, cropW, cropH, pad, pad, inner, inner);
    }

    const result = {
      tabFaviconDataUrl: tabCanvas.toDataURL("image/png"),
      omniboxFaviconDataUrl: omniCanvas.toDataURL("image/png"),
    };
    faviconNormCache.set(rawFaviconUrl, result);
    return result;
  } catch {
    return {
      tabFaviconDataUrl: rawFaviconUrl,
      omniboxFaviconDataUrl: rawFaviconUrl,
    };
  }
}

export async function renderFramedScreenshotToCanvas({
  canvas,
  viewportImage,
  backgroundImage,
  url = 'https://docs.skriptjobs.localhost:3050/getting-started/installation',
  title = 'Installation - Skriptjobs',
  faviconDataUrl = null,
  marginMode = 'reference',
  fitReferenceSize = false,
  viewportCssWidth = null,
  mockupTheme = 'dark',
}) {
  const T = CHROME_MOCKUP_THEME;
  const palette =
    mockupTheme === 'light' ? CHROME_MOCKUP_THEMES.light : CHROME_MOCKUP_THEMES.dark;
  const margins = T.margins[marginMode] || T.margins.reference;

  // Never stretch or deform the screenshot: always preserve the exact aspect ratio of viewportImage.
  const vpW = fitReferenceSize
    ? T.referenceWindow.width - 4
    : (viewportCssWidth || viewportImage.width);
  const vpH = Math.round(viewportImage.height * (vpW / viewportImage.width));
  const winW = vpW + 4;
  const winH = palette.header.totalHeight + vpH + 4;

  const totalW = winW + margins.left + margins.right;
  const totalH = winH + margins.top + margins.bottom;

  // Normalize custom favicon so square favicons completely fill the r=12 circular URL bar badge
  const { tabFaviconDataUrl, omniboxFaviconDataUrl } = await normalizeFaviconForHeader(faviconDataUrl);

  // Preload Header SVG image BEFORE touching the target canvas so there is zero flicker/flashing
  const headerSvg = buildChromeHeaderSvg({
    windowWidth: winW - 4,
    title,
    url,
    faviconDataUrl: tabFaviconDataUrl,
    omniboxFaviconDataUrl,
    mockupTheme,
  });
  const svgBlob = new Blob([headerSvg], { type: 'image/svg+xml;charset=utf-8' });
  const svgUrl = URL.createObjectURL(svgBlob);
  let headerImg;
  try {
    headerImg = await new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = reject;
      img.src = svgUrl;
    });
  } finally {
    URL.revokeObjectURL(svgUrl);
  }

  // Only resize canvas when dimensions actually change (avoids unnecessary buffer reallocation)
  if (canvas.width !== totalW || canvas.height !== totalH) {
    canvas.width = totalW;
    canvas.height = totalH;
  }
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, totalW, totalH);

  // 1. Draw Background Wallpaper (cover)
  if (backgroundImage) {
    const imgRatio = backgroundImage.width / backgroundImage.height;
    const canvasRatio = totalW / totalH;
    let sx = 0, sy = 0, sw = backgroundImage.width, sh = backgroundImage.height;
    if (imgRatio > canvasRatio) {
      sw = backgroundImage.height * canvasRatio;
      sx = (backgroundImage.width - sw) / 2;
    } else {
      sh = backgroundImage.width / canvasRatio;
      sy = (backgroundImage.height - sh) / 2;
    }
    ctx.drawImage(backgroundImage, sx, sy, sw, sh, 0, 0, totalW, totalH);
  } else {
    const grad = ctx.createLinearGradient(0, 0, totalW, totalH);
    grad.addColorStop(0, '#2c2ab3');
    grad.addColorStop(0.5, '#1a90ac');
    grad.addColorStop(1, '#28016b');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, totalW, totalH);
  }

  const winX = margins.left;
  const winY = margins.top;
  const r = T.windowRadius;

  function traceRoundedRect(x, y, w, h, radius) {
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + w - radius, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
    ctx.lineTo(x + w, y + h - radius);
    ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h);
    ctx.lineTo(x + radius, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - radius);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.closePath();
  }

  // 2. Draw macOS Window Drop Shadow
  ctx.save();
  ctx.shadowColor = 'rgba(0, 0, 0, 0.56)';
  ctx.shadowBlur = T.shadow.blurCss;
  ctx.shadowOffsetX = T.shadow.offsetX;
  ctx.shadowOffsetY = T.shadow.offsetY;
  traceRoundedRect(winX, winY, winW, winH, r);
  ctx.fillStyle = palette.borderOuter;
  ctx.fill();
  ctx.restore();

  // 3. Draw Outer 1px Highlight Rim and Inner 1px Rim
  traceRoundedRect(winX, winY, winW, winH, r);
  ctx.fillStyle = palette.borderOuter;
  ctx.fill();

  traceRoundedRect(winX + 1, winY + 1, winW - 2, winH - 2, r - 1);
  ctx.fillStyle = palette.borderInner;
  ctx.fill();

  // 4. Clip to Inner Window Surface (winX+2, winY+2, winW-4, winH-4)
  ctx.save();
  traceRoundedRect(winX + 2, winY + 2, winW - 4, winH - 4, r - 2);
  ctx.clip();

  // 5. Render preloaded Header SVG onto inner top
  ctx.drawImage(headerImg, winX + 2, winY + 2, winW - 4, palette.header.totalHeight);

  // 6. Draw Viewport Image below header
  ctx.fillStyle = palette.viewportFallbackBg;
  ctx.fillRect(winX + 2, winY + 2 + palette.header.totalHeight, vpW, vpH);
  ctx.drawImage(
    viewportImage,
    0,
    0,
    viewportImage.width,
    viewportImage.height,
    winX + 2,
    winY + 2 + palette.header.totalHeight,
    vpW,
    vpH
  );

  ctx.restore();
  return canvas;
}

/**
 * High-level helper used by popup.js and Vue components.
 * Accepts either { screenshotImage, wallpaperImage, pageUrl, pageTitle }
 * or { viewportImage, backgroundImage, url, title } and returns { width, height, canvas }.
 */
export async function renderFramedIssueCanvas({
  canvas,
  screenshotImage,
  viewportImage,
  wallpaperImage,
  backgroundImage,
  pageUrl,
  url,
  pageTitle,
  title,
  faviconDataUrl = null,
  marginMode = 'reference',
  fitReferenceSize = true,
  viewportCssWidth = null,
  mockupTheme = 'dark',
}) {
  const shot = screenshotImage || viewportImage;
  const bg = wallpaperImage || backgroundImage || null;
  const resolvedUrl = pageUrl ?? url ?? 'https://docs.skriptjobs.localhost:3050/getting-started/installation';
  const resolvedTitle = pageTitle ?? title ?? 'Installation - Skriptjobs';

  await renderFramedScreenshotToCanvas({
    canvas,
    viewportImage: shot,
    backgroundImage: bg,
    url: resolvedUrl,
    title: resolvedTitle,
    faviconDataUrl,
    marginMode,
    fitReferenceSize,
    viewportCssWidth,
    mockupTheme,
  });

  return {
    width: canvas.width,
    height: canvas.height,
    canvas,
  };
}
